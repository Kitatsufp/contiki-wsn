obj_sky/aes.o: aes.c aes.h
aes.c aes.h :
