obj_sky/dhcpc.o: ../../../core/net/ip/dhcpc.c ../../../core/./contiki.h \
 ../../../core/./contiki-version.h ../../../platform/sky/./contiki-conf.h \
 ../../../platform/sky/./platform-conf.h \
 ../../../cpu/msp430/./msp430def.h project-conf.h \
 ../../../core/./contiki-default-conf.h ../../../core/./sys/process.h \
 ../../../core/./sys/pt.h ../../../core/./sys/lc.h \
 ../../../core/./sys/lc-switch.h ../../../core/./sys/cc.h \
 ../../../core/./sys/autostart.h ../../../core/./sys/process.h \
 ../../../core/./sys/timer.h ../../../core/./sys/clock.h \
 ../../../core/./sys/ctimer.h ../../../core/./sys/etimer.h \
 ../../../core/./sys/timer.h ../../../core/./sys/etimer.h \
 ../../../core/./sys/rtimer.h ../../../cpu/msp430/./rtimer-arch.h \
 ../../../core/./sys/rtimer.h ../../../core/./sys/pt.h \
 ../../../core/./sys/procinit.h ../../../core/./sys/loader.h \
 ../../../core/./sys/clock.h ../../../core/./sys/energest.h \
 ../../../core/./contiki-net.h ../../../core/./contiki.h \
 ../../../core/./net/ip/tcpip.h ../../../core/./net/ip/uip.h \
 ../../../core/./net/ip/uipopt.h ../../../core/./net/ip/tcpip.h \
 ../../../core/./net/ip/uip.h ../../../core/./net/ipv4/uip-fw.h \
 ../../../core/./net/ipv4/uip-fw-drv.h ../../../core/./net/ipv4/uip-fw.h \
 ../../../core/./net/ipv4/uip_arp.h ../../../core/./net/ip/uiplib.h \
 ../../../core/./net/ip/uip-udp-packet.h \
 ../../../core/./net/ip/simple-udp.h \
 ../../../core/./net/ip/uip-nameserver.h \
 ../../../core/./net/ipv6/uip-icmp6.h ../../../core/./net/ipv6/uip-ds6.h \
 ../../../core/./sys/stimer.h ../../../core/./net/ipv6/uip-nd6.h \
 ../../../core/./net/ipv6/uip-ds6-route.h ../../../core/./lib/list.h \
 ../../../core/./net/ipv6/uip-ds6-nbr.h ../../../core/./net/nbr-table.h \
 ../../../core/./net/linkaddr.h ../../../core/./net/netstack.h \
 ../../../core/./net/llsec/llsec.h ../../../core/./net/mac/mac.h \
 ../../../core/./dev/radio.h ../../../core/./net/mac/rdc.h \
 ../../../core/./net/mac/framer.h ../../../core/./net/ipv6/uip-ds6.h \
 ../../../core/./net/ip/resolv.h ../../../core/./net/ip/uip.h \
 ../../../core/./net/ip/psock.h ../../../core/./contiki-lib.h \
 ../../../core/./lib/list.h ../../../core/./lib/memb.h \
 ../../../core/./lib/mmem.h ../../../core/./lib/random.h \
 ../../../core/./net/ip/udp-socket.h ../../../core/./net/ip/tcp-socket.h \
 ../../../core/./net/rime/rime.h ../../../core/./net/rime/announcement.h \
 ../../../core/./net/rime/collect.h ../../../core/./net/rime/runicast.h \
 ../../../core/./net/rime/stunicast.h ../../../core/./sys/ctimer.h \
 ../../../core/./net/rime/unicast.h ../../../core/./net/rime/broadcast.h \
 ../../../core/./net/rime/abc.h ../../../core/./net/packetbuf.h \
 ../../../core/./net/llsec/llsec802154.h \
 ../../../core/./net/mac/frame802154.h ../../../core/./net/rime/channel.h \
 ../../../core/./net/rime/chameleon.h ../../../core/./net/queuebuf.h \
 ../../../core/./net/rime/neighbor-discovery.h \
 ../../../core/./net/rime/collect-neighbor.h \
 ../../../core/./net/rime/collect-link-estimate.h \
 ../../../core/./net/rime/packetqueue.h ../../../core/./lib/memb.h \
 ../../../core/./net/rime/ipolite.h ../../../core/./net/rime/mesh.h \
 ../../../core/./net/rime/multihop.h \
 ../../../core/./net/rime/route-discovery.h \
 ../../../core/./net/rime/netflood.h \
 ../../../core/./net/rime/polite-announcement.h \
 ../../../core/./net/rime/polite.h ../../../core/./net/rime/rimestats.h \
 ../../../core/./net/rime/rmh.h ../../../core/./net/rime/route.h \
 ../../../core/./net/rime/rucb.h ../../../core/./net/rime/timesynch.h \
 ../../../core/./net/rime/trickle.h ../../../core/./net/netstack.h \
 ../../../core/./net/ip/dhcpc.h
../../../core/net/ip/dhcpc.c ../../../core/./contiki.h :
 ../../../core/./contiki-version.h ../../../platform/sky/./contiki-conf.h :
 ../../../platform/sky/./platform-conf.h :
 ../../../cpu/msp430/./msp430def.h project-conf.h :
 ../../../core/./contiki-default-conf.h ../../../core/./sys/process.h :
 ../../../core/./sys/pt.h ../../../core/./sys/lc.h :
 ../../../core/./sys/lc-switch.h ../../../core/./sys/cc.h :
 ../../../core/./sys/autostart.h ../../../core/./sys/process.h :
 ../../../core/./sys/timer.h ../../../core/./sys/clock.h :
 ../../../core/./sys/ctimer.h ../../../core/./sys/etimer.h :
 ../../../core/./sys/timer.h ../../../core/./sys/etimer.h :
 ../../../core/./sys/rtimer.h ../../../cpu/msp430/./rtimer-arch.h :
 ../../../core/./sys/rtimer.h ../../../core/./sys/pt.h :
 ../../../core/./sys/procinit.h ../../../core/./sys/loader.h :
 ../../../core/./sys/clock.h ../../../core/./sys/energest.h :
 ../../../core/./contiki-net.h ../../../core/./contiki.h :
 ../../../core/./net/ip/tcpip.h ../../../core/./net/ip/uip.h :
 ../../../core/./net/ip/uipopt.h ../../../core/./net/ip/tcpip.h :
 ../../../core/./net/ip/uip.h ../../../core/./net/ipv4/uip-fw.h :
 ../../../core/./net/ipv4/uip-fw-drv.h ../../../core/./net/ipv4/uip-fw.h :
 ../../../core/./net/ipv4/uip_arp.h ../../../core/./net/ip/uiplib.h :
 ../../../core/./net/ip/uip-udp-packet.h :
 ../../../core/./net/ip/simple-udp.h :
 ../../../core/./net/ip/uip-nameserver.h :
 ../../../core/./net/ipv6/uip-icmp6.h ../../../core/./net/ipv6/uip-ds6.h :
 ../../../core/./sys/stimer.h ../../../core/./net/ipv6/uip-nd6.h :
 ../../../core/./net/ipv6/uip-ds6-route.h ../../../core/./lib/list.h :
 ../../../core/./net/ipv6/uip-ds6-nbr.h ../../../core/./net/nbr-table.h :
 ../../../core/./net/linkaddr.h ../../../core/./net/netstack.h :
 ../../../core/./net/llsec/llsec.h ../../../core/./net/mac/mac.h :
 ../../../core/./dev/radio.h ../../../core/./net/mac/rdc.h :
 ../../../core/./net/mac/framer.h ../../../core/./net/ipv6/uip-ds6.h :
 ../../../core/./net/ip/resolv.h ../../../core/./net/ip/uip.h :
 ../../../core/./net/ip/psock.h ../../../core/./contiki-lib.h :
 ../../../core/./lib/list.h ../../../core/./lib/memb.h :
 ../../../core/./lib/mmem.h ../../../core/./lib/random.h :
 ../../../core/./net/ip/udp-socket.h ../../../core/./net/ip/tcp-socket.h :
 ../../../core/./net/rime/rime.h ../../../core/./net/rime/announcement.h :
 ../../../core/./net/rime/collect.h ../../../core/./net/rime/runicast.h :
 ../../../core/./net/rime/stunicast.h ../../../core/./sys/ctimer.h :
 ../../../core/./net/rime/unicast.h ../../../core/./net/rime/broadcast.h :
 ../../../core/./net/rime/abc.h ../../../core/./net/packetbuf.h :
 ../../../core/./net/llsec/llsec802154.h :
 ../../../core/./net/mac/frame802154.h ../../../core/./net/rime/channel.h :
 ../../../core/./net/rime/chameleon.h ../../../core/./net/queuebuf.h :
 ../../../core/./net/rime/neighbor-discovery.h :
 ../../../core/./net/rime/collect-neighbor.h :
 ../../../core/./net/rime/collect-link-estimate.h :
 ../../../core/./net/rime/packetqueue.h ../../../core/./lib/memb.h :
 ../../../core/./net/rime/ipolite.h ../../../core/./net/rime/mesh.h :
 ../../../core/./net/rime/multihop.h :
 ../../../core/./net/rime/route-discovery.h :
 ../../../core/./net/rime/netflood.h :
 ../../../core/./net/rime/polite-announcement.h :
 ../../../core/./net/rime/polite.h ../../../core/./net/rime/rimestats.h :
 ../../../core/./net/rime/rmh.h ../../../core/./net/rime/route.h :
 ../../../core/./net/rime/rucb.h ../../../core/./net/rime/timesynch.h :
 ../../../core/./net/rime/trickle.h ../../../core/./net/netstack.h :
 ../../../core/./net/ip/dhcpc.h :
