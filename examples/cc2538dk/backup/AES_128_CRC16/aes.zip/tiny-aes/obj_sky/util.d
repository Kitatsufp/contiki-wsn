obj_sky/util.o: util.c util.h aes.h
util.c util.h aes.h :
