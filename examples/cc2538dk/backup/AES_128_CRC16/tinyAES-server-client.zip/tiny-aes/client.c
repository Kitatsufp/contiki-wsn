#include "contiki.h"
#include "contiki-lib.h"
#include "contiki-net.h"

#include <string.h>
#include "dev/leds.h"
#include "dev/button-sensor.h"
#include "debug.h"

#define CLIENT 1
/*---------------------------------------------------------------------------*/
/*************************| AES128 (START) |                                 */
/*---------------------------------------------------------------------------*/
#include <stdio.h>
#include <string.h>
#include <stdint.h>

#define CBC 1
#define ECB 0

#if ECB
#define MAX_LEN_ECB 16
#define MAX_PAYLOAD_LEN MAX_LEN_ECB
#endif

#if CBC
#define MAX_LEN_CBC 64
#define MAX_PAYLOAD_LEN MAX_LEN_CBC
#endif

#include "aes.h"
/*---------------------------------------------------------------------------*/
/*                        |  AES128 (END) |***********************************/
/*---------------------------------------------------------------------------*/

#define DEBUG DEBUG_PRINT
#include "net/ip/uip-debug.h"

#define SEND_INTERVAL		5 * CLOCK_SECOND

#define GLOBAL_CONN_PORT 3001
static struct uip_udp_conn *g_conn;

/*---------------------------------------------------------------------------*/
/*************************| AES128 (START) |                                 */
/*---------------------------------------------------------------------------*/
static void phex_16(uint8_t* data_16);
static void phex_64(uint8_t* data_64);

/*
#if CLIENT
static void decrypt_cbc(uint8_t* data_decrypted, uint8_t* data_encrypted);
static uint8_t data_received  [MAX_LEN_CBC];
static uint8_t data_decrypted [MAX_LEN_CBC];
static uint8_t data_reply     [MAX_LEN_CBC];
#endif
*/
static void encrypt_cbc(uint8_t* data_encrypted, uint8_t* data);
static uint8_t data_encrypted [MAX_LEN_CBC];
static uint8_t data_temp [MAX_LEN_CBC];


static uint8_t key[16] = { 0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, \
                           0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c };

static uint8_t iv[16]  = { 0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, \
                           0x08, 0x09, 0x0a, 0x0b, 0x0c, 0x0d, 0x0e, 0x0f };

static uint8_t data[MAX_LEN_CBC]  = { 0x6b, 0xc1, 0xbe, 0xe2, 0x2e, 0x40, 0x9f, 0x96, \
                                      0xe9, 0x3d, 0x7e, 0x11, 0x73, 0x93, 0x17, 0x2a, \
                                      0xae, 0x2d, 0x8a, 0x57, 0x1e, 0x03, 0xac, 0x9c, \
                                      0x9e, 0xb7, 0x6f, 0xac, 0x45, 0xaf, 0x8e, 0x51, \
                                      0x30, 0xc8, 0x1c, 0x46, 0xa3, 0x5c, 0xe4, 0x11, \
                                      0xe5, 0xfb, 0xc1, 0x19, 0x1a, 0x0a, 0x52, 0xef, \
                                      0xf6, 0x9f, 0x24, 0x45, 0xdf, 0x4f, 0x9b, 0x17, \
                                      0xad, 0x2b, 0x41, 0x7b, 0xe6, 0x6c, 0x37, 0x10 };
/*---------------------------------------------------------------------------*/
/*                        |  AES128 (END) |***********************************/
/*---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*/
PROCESS(udp_client_process, "UDP client process");
AUTOSTART_PROCESSES(&udp_client_process);
/*---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*/
/*************************| AES128 (START) |                                 */
/*---------------------------------------------------------------------------*/
static void 
phex_16(uint8_t* data_16) 
{ // in chuoi hex 16 bytes
    unsigned char i;
    for(i = 0; i < 16; ++i)
        printf("%.2x ", data_16[i]);
    printf("\n");
}
/*---------------------------------------------------------------------------*/
static void 
phex_64(uint8_t* data_64) 
{ // in chuoi hex 64 bytes
    unsigned char i;
    for(i = 0; i < 4; ++i) 
        phex_16(data_64 + (i*16));
    printf("\n");
}
/*---------------------------------------------------------------------------*/
// ma hoa 64 bytes
static void 
encrypt_cbc(uint8_t* data_encrypted, uint8_t* data) 
{ // ma hoa 64 bytes
    printf("\nData: \n");
    phex_64(data);

    AES128_CBC_encrypt_buffer(data_encrypted, data, 64, key, iv);

    printf("\nData encrypted: \n");
    phex_64(data_encrypted);
}
/*---------------------------------------------------------------------------*/
/*
#if CLIENT
// giai hoa 64 bytes
static void 
decrypt_cbc(uint8_t* data_decrypted, uint8_t* data_encrypted) 
{
  printf("\nData_encrypted: \n");
  phex_64(data_decrypted);

  AES128_CBC_decrypt_buffer(data_decrypted+0,  data_encrypted+0,  16, key, iv);
  AES128_CBC_decrypt_buffer(data_decrypted+16, data_encrypted+16, 16, 0, 0);
  AES128_CBC_decrypt_buffer(data_decrypted+32, data_encrypted+32, 16, 0, 0);
  AES128_CBC_decrypt_buffer(data_decrypted+48, data_encrypted+48, 16, 0, 0);

  printf("\nData decrypt: \n");
  phex_64(data_decrypted);
}
#endif
*/
/*---------------------------------------------------------------------------*/
/*                        |  AES128 (END) |***********************************/
/*---------------------------------------------------------------------------*/

static void
tcpip_handler(void)
{
  leds_on(LEDS_GREEN);
  if(uip_newdata()) {
    clock_delay(5000);
  }
  leds_off(LEDS_GREEN);
  return;
}
/*---------------------------------------------------------------------------*/
static void
timeout_handler(void)
{
  static int seq_id;
  struct uip_udp_conn *this_conn;
  
  leds_on(LEDS_RED);
  seq_id++;
  printf("seq_id = %d\n", seq_id);

  this_conn = g_conn;
  if(uip_ds6_get_global(ADDR_PREFERRED) == NULL) {
      return;
  }

  PRINTF("Client to: ");
  PRINT6ADDR(&this_conn->ripaddr);
  PRINTF(" Remote Port %u,", UIP_HTONS(this_conn->rport));

  memcpy(data_temp, data, MAX_LEN_CBC);
  encrypt_cbc(data_encrypted, data_temp);

  uip_udp_packet_send(this_conn, data_encrypted, MAX_LEN_CBC);
  leds_off(LEDS_RED);
}
/*---------------------------------------------------------------------------*/
PROCESS_THREAD(udp_client_process, ev, data)
{
  static struct etimer et;
  uip_ipaddr_t ipaddr;

  PROCESS_BEGIN();
  PRINTF("UDP client process started\n");


  uip_ip6addr(&ipaddr, 0xaaaa, 0, 0, 0, 0x0212, 0x7401, 0x0001, 0x0101);
  g_conn = udp_new(&ipaddr, UIP_HTONS(3000), NULL);
  if(!g_conn) {
    PRINTF("udp_new g_conn error.\n");
  }
  udp_bind(g_conn, UIP_HTONS(GLOBAL_CONN_PORT));

  PRINTF("Global connection with ");
  PRINT6ADDR(&g_conn->ripaddr);
  PRINTF(" local/remote port %u/%u\n",
         UIP_HTONS(g_conn->lport), UIP_HTONS(g_conn->rport));

  etimer_set(&et, SEND_INTERVAL);
  
  while(1) {
    PROCESS_YIELD();
    if(etimer_expired(&et)) {
  		PRINTF("\n/*--------------------- timeout_handler ---------------------------*/\n");
		  timeout_handler();
      etimer_restart(&et);
    } else if(ev == tcpip_event) {
      	tcpip_handler();
    }
  }
  PROCESS_END();
}
/*---------------------------------------------------------------------------*/
