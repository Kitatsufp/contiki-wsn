#include "contiki.h"
#include "contiki-lib.h"
#include "contiki-net.h"

#include <string.h>

#define DEBUG DEBUG_PRINT
#include "net/ip/uip-debug.h"
#include "dev/watchdog.h"
#include "dev/leds.h"
#include "net/rpl/rpl.h"
#include "dev/button-sensor.h"
#include "debug.h"

/*---------------------------------------------------------------------------*/
/*************************| AES128 (START) |                                 */
/*---------------------------------------------------------------------------*/
#include <stdio.h>
#include <string.h>
#include <stdint.h>

#define CBC 1
#define ECB 0

#if ECB
#define MAX_LEN_ECB 16
#define MAX_PAYLOAD_LEN MAX_LEN_ECB
#endif

#if CBC
#define MAX_LEN_CBC 64
#define MAX_PAYLOAD_LEN MAX_LEN_CBC
#endif

#include "aes.h"
/*---------------------------------------------------------------------------*/
/*                        |  AES128 (END) |***********************************/
/*---------------------------------------------------------------------------*/

#define UIP_IP_BUF   ((struct uip_ip_hdr *)&uip_buf[UIP_LLH_LEN])
#define UIP_UDP_BUF  ((struct uip_udp_hdr *)&uip_buf[uip_l2_l3_hdr_len])

static struct uip_udp_conn *server_conn;
static uint16_t len;

/* Reply msg? */                         
#define SERVER_REPLY          0

/* Should we act as RPL root? */
#define SERVER_RPL_ROOT       1

#if SERVER_RPL_ROOT
static uip_ipaddr_t ipaddr;
#endif
/*---------------------------------------------------------------------------*/
/*************************| AES128 (START) |                                 */
/*---------------------------------------------------------------------------*/
static void phex_16(uint8_t* data_16);
static void phex_64(uint8_t* data_64);
static void decrypt_cbc(uint8_t* data_decrypted, uint8_t* data_encrypted);

static uint8_t data_received  [MAX_LEN_CBC];
static uint8_t data_decrypted [MAX_LEN_CBC];


/*
#if SERVER_REPLY
static void encrypt_cbc(uint8_t* data_encrypted, uint8_t* data);
static uint8_t data_encrypted [MAX_LEN_CBC];
static uint8_t data_reply     [MAX_LEN_CBC];
static uint8_t data_temp      [MAX_LEN_CBC];
#endif
*/
static uint8_t key[16] = { 0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, \
                           0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c };

static uint8_t iv[16]  = { 0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, \
                           0x08, 0x09, 0x0a, 0x0b, 0x0c, 0x0d, 0x0e, 0x0f };
/*---------------------------------------------------------------------------*/
/*                        |  AES128 (END) |***********************************/
/*---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*/
PROCESS(udp_server_process, "UDP server process");
AUTOSTART_PROCESSES(&udp_server_process);
/*---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*/
/*************************| AES128 (START) |                                 */
/*---------------------------------------------------------------------------*/
static void 
phex_16(uint8_t* data_16) 
{ // in chuoi hex 16 bytes
    unsigned char i;
    for(i = 0; i < 16; ++i)
        printf("%.2x ", data_16[i]);
    printf("\n");
}
/*---------------------------------------------------------------------------*/
static void 
phex_64(uint8_t* data_64) 
{ // in chuoi hex 64 bytes
    unsigned char i;
    for(i = 0; i < 4; ++i) 
        phex_16(data_64 + (i*16));
    printf("\n");
}
/*---------------------------------------------------------------------------*/
/*
#if SERVER_REPLY
// ma hoa 64 bytes
static void 
encrypt_cbc(uint8_t* data_encrypted, uint8_t* data) 
{ // ma hoa 64 bytes
    printf("\nData: \n");
    phex_64(data);

    AES128_CBC_encrypt_buffer(data_encrypted, data, 64, key, iv);

    printf("\nData encrypted: \n");
    phex_64(data_encrypted);
}
#endif
*/
/*---------------------------------------------------------------------------*/
// giai hoa 64 bytes
static void 
decrypt_cbc(uint8_t* data_decrypted, uint8_t* data_encrypted) 
{
	printf("\nData encrypted: \n");
  phex_64(data_encrypted);

  AES128_CBC_decrypt_buffer(data_decrypted+0,  data_encrypted+0,  16, key, iv);
  AES128_CBC_decrypt_buffer(data_decrypted+16, data_encrypted+16, 16, 0, 0);
  AES128_CBC_decrypt_buffer(data_decrypted+32, data_encrypted+32, 16, 0, 0);
  AES128_CBC_decrypt_buffer(data_decrypted+48, data_encrypted+48, 16, 0, 0);

  printf("\nData decrypt: \n");
	phex_64(data_decrypted);
}
/*---------------------------------------------------------------------------*/
/*                        |  AES128 (END) |***********************************/
/*---------------------------------------------------------------------------*/
static void 
tcpip_handler(void)
{
  memset(data_received, 0, MAX_LEN_CBC);

  if(uip_newdata()) {
    leds_on(LEDS_RED);

    len = uip_datalen();
    memcpy(data_received, uip_appdata, len);

    PRINTF("%u bytes from [", len);
    PRINT6ADDR(&UIP_IP_BUF->srcipaddr);
    PRINTF("]:%u\n", UIP_HTONS(UIP_UDP_BUF->srcport));

		decrypt_cbc(data_decrypted, data_received);

#if SERVER_REPLY
    uip_ipaddr_copy(&server_conn->ripaddr, &UIP_IP_BUF->srcipaddr);
    server_conn->rport = UIP_UDP_BUF->srcport;

    memcpy(data_reply, data_decrypted, len);

    memcpy(data_temp, data_reply, len);
    encrypt_cbc(data_encrypted, data_temp);
    uip_udp_packet_send(server_conn, data_encrypted, len);
    /* Restore server connection to allow data from any node */
    uip_create_unspecified(&server_conn->ripaddr);
    server_conn->rport = 0;
#endif

  }
  leds_off(LEDS_RED);
  return;
}
/*---------------------------------------------------------------------------*/
static void
print_local_addresses(void)
{
  int i;
  uint8_t state;

  PRINTF("Server IPv6 addresses:\n");
  for(i = 0; i < UIP_DS6_ADDR_NB; i++) {
    state = uip_ds6_if.addr_list[i].state;
    if(uip_ds6_if.addr_list[i].isused && (state == ADDR_TENTATIVE || state
        == ADDR_PREFERRED)) {
      PRINTF("  ");
      PRINT6ADDR(&uip_ds6_if.addr_list[i].ipaddr);
      PRINTF("\n");
      if(state == ADDR_TENTATIVE) {
        uip_ds6_if.addr_list[i].state = ADDR_PREFERRED;
      }
    }
  }
}
/*---------------------------------------------------------------------------*/
#if SERVER_RPL_ROOT
void
create_dag()
{
  rpl_dag_t *dag;

  uip_ip6addr(&ipaddr, 0xaaaa, 0, 0, 0, 0, 0, 0, 0);
  uip_ds6_set_addr_iid(&ipaddr, &uip_lladdr);
  uip_ds6_addr_add(&ipaddr, 0, ADDR_AUTOCONF);

  print_local_addresses();

  dag = rpl_set_root(RPL_DEFAULT_INSTANCE,
                     &uip_ds6_get_global(ADDR_PREFERRED)->ipaddr);
  if(dag != NULL) {
    uip_ip6addr(&ipaddr, 0xaaaa, 0, 0, 0, 0, 0, 0, 0);
    rpl_set_prefix(dag, &ipaddr, 64);
    PRINTF("Created a new RPL dag with ID: ");
    PRINT6ADDR(&dag->dag_id);
    PRINTF("\n");
  }
}
#endif /* SERVER_RPL_ROOT */
/*---------------------------------------------------------------------------*/
PROCESS_THREAD(udp_server_process, ev, data)
{

  PROCESS_BEGIN();
  printf("Starting UDP server\n");

#if SERVER_RPL_ROOT
  create_dag();
#endif

  server_conn = udp_new(NULL, UIP_HTONS(0), NULL);
  udp_bind(server_conn, UIP_HTONS(3000));

  PRINTF("Listen port: 3000, TTL=%u\n", server_conn->ttl);

  while(1) {
    PROCESS_YIELD();
    if(ev == tcpip_event) {
      tcpip_handler();
    }
  }
  PROCESS_END();
}
/*---------------------------------------------------------------------------*/
